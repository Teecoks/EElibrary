import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import { Left, Icon, Right } from 'native-base';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import Styles from "./Styles"
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;
Screen5 = () => {

}
class Screen5 extends Component {
    constructor() {
        super(); this.state = { firstName: "", email:"", lastName:"", phone:"",  }
    }
    componentDidMount(){
        this.retrieveData()
    }
    retrieveData = async (key) => {
        try {
          const value = await AsyncStorage.getItem('first_name');
          if (value !== null) {
            // We have data!!
             this.setState({firstName: value})
          }
        } catch (error) {
          // Error retrieving data
        }
    
        try {
            const value = await AsyncStorage.getItem('email');
            if (value !== null) {
              // We have data!!
               this.setState({email: value})
            }
          } catch (error) {
            // Error retrieving data
          }
          try {
            const value = await AsyncStorage.getItem('last_name');
            if (value !== null) {
              // We have data!!
               this.setState({lastName: value})
            }
          } catch (error) {
            // Error retrieving data
          }
          try {
            const value = await AsyncStorage.getItem('id');
            if (value !== null) {
              // We have data!!
               this.setState({ID: value})
            }
          } catch (error) {
            // Error retrieving data
          }
          try {
            const value = await AsyncStorage.getItem('phone');
            if (value !== null) {
              // We have data!!
               this.setState({phone: value})
            }
          } catch (error) {
            // Error retrieving data
          }
    
        
      };
      
    render() {
        return (
            <View style={Styles.view1} >
                <View style={Styles.headerview} >
                    <TouchableOpacity
                        onPress={() => {
                            Actions.pop()
                        }
                        }
                    >
                        <Left>
                            <Icon style={Styles.iconviewleft}
                                name='arrowleft'
                                type='AntDesign'
                            />
                        </Left>

                    </TouchableOpacity>
                    <Text style={Styles.headertextsize}>TCLI Found</Text>

                </View>
                <View style={Styles.Viewbackground} >
                    <View style={Styles.Viewbackground2}>
                    <View style={{width:"100%",height:35, justifyContent:"flex-end"}}>
                    <TouchableOpacity
                    onPress={()=>{
                        Actions.updateprofile()
                    }
                     }
                    >
                    <Icon style={{ color:"white",paddingLeft:300 }}
                 name="account-edit"
                 type="MaterialCommunityIcons"
                 />
                 </TouchableOpacity>
                 </View>
                        <Image source={require('../projectpics/user.png')}
                            style={{ width: 130, height: 130 }} />
                        <Text style={{ color: "white", marginVertical: 15 }}>{this.state.firstName} {this.state.lastName}</Text>
                
                    </View>
                    <View style={Styles.middlemainview}>
                        <View style={Styles.middlesubview}>
                            <Text style={Styles.middletext}>Books Read</Text>
                            <Text style={Styles.middletext2}>3</Text>
                        </View>
                        <View style={Styles.middlesubview}>
                            <Text style={Styles.middletext}>Favorite Genre</Text>
                            <Text style={Styles.middletext2}>Adventure</Text>
                        </View>
                    </View>

                    <View style={Styles.infotextview}>

                    <View style={{width:60,height:30}}></View>
                            <Icon style={{justifyContent:"center" ,alignItems: "center", paddingLeft:10 }}
                                name='email'
                                type='MaterialCommunityIcons'
                            />
                        <View style={{width:60,height:30}}></View>
                        <TextInput style={{width:"50%",height:40,color:"purple"}}
                            editable={false}
                            onChangeText={(text) => { this.setState({ email: text }) }}
                            value={this.state.email} 
                           
                            />
                    </View>

                    <View style={Styles.infotextview}>
                        
                    <View style={{width:60,height:30}}></View>
                            <Icon style={Styles.iconview}
                                name='md-call'
                                type='Ionicons'
                            />
                             <View style={{width:70,height:30}}></View>
                        <TextInput style={{width:"50%",height:40,color:"purple"}}
                            editable={false}
                            onChangeText={(text) => { this.setState({ phone: text }) }}
                            value={this.state.phone} 
                            
                            />
                        
                    </View>

                    <View style={Styles.infotextview}>
                    <View style={{width:40,height:30}}></View>
                            <Icon style={Styles.iconview}
                                name='bookmark'
                                type='Entypo'
                            />
                        <View style={{width:60,height:30}}></View>
                        <Text style={{color:"purple"}}>Continue:Broken</Text>
                        <View style={{width:70,height:30}}></View>
                    </View>

                    <View style={Styles.infotextview}>
                    <View style={{width:35,height:30}}></View>
                            <Icon style={Styles.iconview}
                                name='star'
                                type='Entypo'
                            />
                        <View style={{width:65,height:30}}></View>
                        <Text style={{color:"purple"}}>Acheivements</Text>
                        <View style={{width:70,height:30}}></View>
                    </View>
                </View>



            </View>
        )
    }
}
export default Screen5;