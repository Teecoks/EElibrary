import React, { Component } from 'react';
import { Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import { Button } from 'react-native';
import Styles from "./Styles"
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;

export default class Screen9 extends Component {
    render() {
        return (
            <View style={{ flex: 1, backgroundColor: "purple", marginTop: 30 }} >
                <View style={{ width: "100%", height: 40, backgroundColor: "pink", marginTop: 10, alignItems: "center", justifyContent: "center" }} >
                    <Text style={{ fontSize: 20, }}>Galactic Core 1</Text>
                </View>

                <View style={{ width: "100%", height: "80%", backgroundColor: "purple", alignItems: "center", justifyContent: "space-around" }} >

                    <Image source={require("../projectpics/logo.jpg")}
                        style={Styles.imageview} />

                    <Text style={{ fontSize: 20, fontWeight: "bold" }}> Author:Emmanuel Ozor </Text>
                    <Text style={{ fontSize: 20, fontWeight: "bold" , paddingBottom:20}}>Description:None Available  </Text>
                </View>
                <View style={{ width: "100%", height: 50, paddingBottom: 50, justifyContent: "center", alignItems: "center", backgroundColor: "purple" }} >
                    <View style={{ width: "70%", height: 40, justifyContent: "center", alignItems: "center", backgroundColor: "silver" }} >
                        <TouchableOpacity
                            onPress={this.onPressLearnMore}>
                            <Text style={{ fontSize: 15, alignItems: "center", justifyContent: "center", }}>Sign Book And Start Reading</Text>
                        </TouchableOpacity>
                    </View>


                </View>
            </View>
        )
    }
}