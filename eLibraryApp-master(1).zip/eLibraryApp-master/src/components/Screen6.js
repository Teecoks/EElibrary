import React, { Component } from 'react';
import Styles from "./Styles"
import { AppRegistry, Alert, ScrollView, Image, Button, StyleSheet, TouchableOpacity, Text, TextInput, View } from 'react-native';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import { Left, Icon } from 'native-base';
Screen6 = () => {

}
class Screen6 extends Component {
  render() {
    return (
      <View style={{ flex: 1 }}>

        <View style={{
          width: "100%", height: 50, justifyContent: "space-between",
          alignItems: "center", marginBottom: 2, backgroundColor: "white", flexDirection: "row"
        }} >
          <TouchableOpacity
            onPress={() => {
              Actions.pop()
            }}
          >
            <Icon style={{ color: "purple", marginLeft: 10 }}
              name='arrowleft'
              type='AntDesign'

            />
          </TouchableOpacity>
         
          <Text style={{ fontWeight: "bold", fontSize: 25,color:"purple" }}>Search Books</Text>
          <View style={{ width: 40, height: 30 }}>
          </View>
        </View>
        <View  style={{ width: "100%", height: 50, justifyContent: "center",
         alignItems: "center", backgroundColor: "purple",flexDirection:"row" }}>
        <Icon style={{color:"white",fontSize:20}}
          name="search1"
          type="AntDesign"
          />
        
        <TextInput style={{ width: "90%", height: 50, justifyContent: "center",
         alignItems: "center", backgroundColor: "purple" }}
         
          placeholder=" Search"
          placeholderTextColor="white"
          />
         </View>
        <View style={{width:"100%",height:30,justifyContent:"center",alignItems:"center",borderTopWidth:1,borderTopColor:"white" ,borderBottomWidth:.5,borderBottomColor:"purple"}}>
        <Text style = {{fontSize:20, color:"purple"}}>Recent Searches</Text>
        </View>
        <ScrollView>
          <View style={{ width: "100%", height: 450, backgroundColor: "white" }} >
            <Text style={{ marginLeft: 10, fontSize: 25, fontWeight: "bold",color:"purple", paddingVertical: 10 }}>Broken(Book Name)</Text>
            <View style={{ backgroundColor: "white", alignItems: "center", justifyContent: "center" }} >
              <Image source={require("../projectpics/Broken.png")}
                style={Styles.imageview} />
            </View>
            <Text style={{ fontSize: 20, fontWeight: "bold" }}> type here anything.....</Text>
            <TouchableOpacity style={{
              width: "90%",
              height: 40,
              marginTop: 10,
              alignSelf: "center",
              justifyContent: "center",
              backgroundColor: "purple",
              marginRight: 10,
              borderRadius:5
            }}
            onPress={() => {
              Actions.tag()
            }
            }
            >
              <Text style={{ alignSelf: "center",color:"white", justifyContent: "center" }}>Show more</Text>
            </TouchableOpacity>
          </View>

          <View style={{ marginTop: 10, width: "100%", height: 450, backgroundColor: "white" }} >
            <Text style={{ marginLeft: 10, fontSize: 25, fontWeight: "bold",color:"purple", paddingVertical: 10 }}>Once Upon</Text>
            <View style={{ backgroundColor: "white", alignItems: "center", justifyContent: "center" }} >
              <Image source={require("../projectpics/Love.png")}
                style={Styles.imageview} />
            </View>
            <Text style={{ fontSize: 20, fontWeight: "bold" }}> Type Here..</Text>
            <TouchableOpacity style={{
              width: "90%",
              height: 40,
              marginTop: 10,
              alignSelf: "center",
              justifyContent: "center",
              backgroundColor: "purple",
              marginRight: 10,
              borderRadius:5
            }}
              onPress={() => {
                Actions.tag()
              }
              }
            >
              <Text style={{ alignSelf: "center",color:"white", justifyContent: "center" }}>Show more</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </View>
    )
  }
}
export default Screen6;