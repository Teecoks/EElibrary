import React, { Component } from 'react';
import { Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import { Button } from 'react-native';
import Styles from "./Styles"
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;

export default class Manageadmin extends Component {

    constructor() {
        super(); this.state = { Email: "Prissy", Password: "Coks" }
    }
    onPressLearnMore = () => {

    }
    render() {
        return (
            <View style={Styles.manageadminmainview}>

                <Text style={Styles.textaccount}>Admin</Text>

                <TouchableOpacity style={Styles.manageadminmaintext}>
                    <Text style={Styles.booktextfont}>Book Uploads</Text>
                    <Text style={Styles.textinbook}>Upload new books and manage books that you have uploaded</Text>

                </TouchableOpacity>

                <TouchableOpacity style={Styles.manageadminmaintext2}>
                    <Text style={Styles.booktextfont}>Manage Admins</Text>
                    <Text style={Styles.textinbook}>You can create a new admins to upload books and manage them all at the same time</Text>
                </TouchableOpacity>


            </View>
        )
    }
}