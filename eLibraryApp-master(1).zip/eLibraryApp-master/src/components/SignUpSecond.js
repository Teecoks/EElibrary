//SignUp.js

import React from 'react'
import { StyleSheet, Text, TextInput, View, Button, ScrollView, Dimensions, Image, TouchableOpacity, onPress, AppRegistry, KeyboardAvoidingView } from 'react-native'
import firebase from 'firebase'
import { Content, Icon } from 'native-base';
import connect from "react-redux"
import Styles from "./Styles"
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import CountryPicker, { getAllCountries } from 'react-native-country-picker-modal';
import Firebase from './firebase';


const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;


export default class SignUpSecond extends React.Component {
  state = { 
    Firstname: '',
    Lastname: '',  
    cca2: 'US',
    callingCode: 1,
    errorMessage: null
}

saveUserDetails = () => {
    const { Firstname, Lastname, cca2, callingCode } = this.state
    const { currentUser } = firebase.auth();
    firebase.database().ref(`/users/${currentUser.uid}/userDetails`)
    .push({ Firstname, Lastname, cca2, callingCode })
    .then(user => this.props.navigation.navigate("accountlogin"));
  }


  render() {
    return (
        <View style={{ backgroundColor: "white", height: screenheight }}>

<KeyboardAvoidingView
      style={Styles.kbview2}
      behavior="padding"
      >

                <View style={Styles.view2signupscreen} >
                    <Image source={require('../projectpics/logo.jpg')}
                    style={Styles.imageviewsignupscreen} />
        </View>

        <View style={Styles.view3signupscreen}>
            <TextInput style={Styles.nameview}
                placeholder="First Name"
                placeholderTextColor="white"
                onChangeText={(text) => { this.setState({ Firstname: text }) }}
                value={this.state.Firstname}
            />



            <TextInput style={Styles.nameview}
                placeholder="Last Name"
                placeholderTextColor="white"
                onChangeText={(text) => { this.setState({ Lastname: text }) }}
                value={this.state.Lastname}
                ref={(Input) => this.last = Input}
            />
        
              
        {this.state.errorMessage &&
          <Text style={{ color: 'red' }}>
            {this.state.errorMessage}
          </Text>}

          <TouchableOpacity>
          <View style={{
              width: "90%",
              height: 40,
              marginHorizontal: 20,
              borderBottomWidth: 0.5,
              borderBottomColor: 'black',
              color: "white",
              alignSelf: "center"
          }}

          >
              <View style={{
                  width: "100%",
                  height: 40,
                  flexDirection:"row",
                  alignItems:"center"
              }}>
              
                  <CountryPicker style={{ backgroundColor: "gray", width: '100%', }}

                      onChange={value => {
                          this.setState({ cca2: value.cca2, callingCode: value.callingCode })
                      }}
                      cca2={this.state.cca2}
                      translation="eng"
                  />
                    <Text style={{paddingLeft:100,color:"white",opacity:.5 }}>Touch on Flag</Text>

                                </View>
                            </View>
                        </TouchableOpacity>  

            <View style={{ height: 20 }} />
        
              <TouchableOpacity style={Styles.buttonview}
                    onPress={this.saveUserDetails} >
                    <Text style={Styles.fonttext21}>Sign Up</Text>
               </TouchableOpacity>
               
               <View style={{ height: 12 }} />


               <TouchableOpacity
                    onPress={() => this.props.navigation.navigate('Login')} >
                    <Text style={Styles.fonttext}>Already have an Account? Log In</Text>
                </TouchableOpacity>

    
      </View>

      </KeyboardAvoidingView>
      
      
            </View>
    )
  }
}
