import React, { Component } from 'react';
import { Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import Styles from "./Styles"
import { Left, Icon } from 'native-base';
import { Actions } from 'react-native-router-flux';
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;

class Loginsuccess extends Component {

    Loginsuccess = ()=>{

    }


    render() {
        return (
            <View style={Styles.view1} >
                <View style={Styles.headerview} >
                    <TouchableOpacity 
                     onPress={() => {
                       
                        Actions.drawerOpen()
                    
                }
                }
                    >
                        <Left>
                            <Icon style={Styles.iconviewleft}
                                name='menu-fold'
                                type='AntDesign'
                            />
                        </Left>

                    </TouchableOpacity>
                    
                    <Text style={Styles.headertextsize}>TCLI</Text>

                </View>
                <View style={Styles.view2} >
                <Image source={require('../projectpics/logo.jpg')}
                        style={Styles.imageview} />
                </View>



            </View>
        )
    }
}
export default Loginsuccess;