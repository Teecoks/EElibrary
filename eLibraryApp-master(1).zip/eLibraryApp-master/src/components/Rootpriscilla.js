import React, { Component } from 'react';
import { Platform, StyleSheet, Button, Text, View, ScrollView, FlatList, TouchableOpacity, Dimensions } from 'react-native';
import { Actions, Router, Scene, Stack, Drawer } from 'react-native-router-flux';
import Login from './Login';
import SignUp from './SignUp';
import Draweranditems from './Draweranditems';
import Loginsuccess from './Loginsuccess';
import Screen5 from './Screen5';
import Screen6 from './Screen6';
import Screen7 from './Screen7';
import Screen8 from './Screen8';
import Contactdetails from './Contactdetails';
import Changepassword from './Changepassword';
import Main from './Main';
import Mylibrary from './Mylibrary';
import Account from './Account';
import Forgotpassword from './Forgotpassword';
import Profileupdate from './Profileupdate';
import TestShare from './Share';
import updateprofile from './Profileupdate';
import SignUpSecond from './SignUpSecond';
const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

class Rootpriscilla extends Component {
    render() {
        return (
            <Router>
                <Scene hideNavBar={true}>

                    <Drawer key="drawer" contentComponent={Draweranditems}>
                        <Scene key="Press" drawer={false} component={Main} hideNavBar={true} />
                        <Scene key="Login" initial={true} component={Login} hideNavBar={true} />
                        <Scene key="accountsignup" component={Login} hideNavBar={true} />
                        <Scene key="accountlogin" component={Main} hideNavBar={true} />
                        <Scene key="forgot" component={Forgotpassword} hideNavBar={true} />
                    </Drawer>

                    <Scene key="Bookreading" component={Screen8} />
                    <Scene key="account" component={Account} hideNavBar={true} />
                    <Scene key="share" component={TestShare} hideNavBar={true} />
                    <Scene key="profile" component={Screen5} hideNavBar={true} />
                    <Scene key="updateprofile" component={Profileupdate} hideNavBar={true} />
                    <Scene key="Library" component={Mylibrary} hideNavBar={true} />
                    <Scene key="SignUp" component={SignUp} hideNavBar={true} />
                    <Scene key="SignUpSecond" component={SignUpSecond} hideNavBar={true} />
                    <Scene key="mail" component={Changepassword} hideNavBar={true} />
                    <Scene key="Booksavailable" component={Screen6} hideNavBar={true} />
                    <Scene key="Contact" component={Contactdetails} hideNavBar={true} />
                    <Scene key="tag" component={Screen7} hideNavBar={true} />
                </Scene>
            </Router >
        );
    }
}
export default Rootpriscilla;