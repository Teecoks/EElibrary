import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {Text, View, TouchableOpacity, AppRegistry, TextInput, Image, ScrollView } from 'react-native';
import { Icon, Left } from 'native-base';
import { Actions, Router, Scene, Stack, Drawer } from 'react-native-router-flux';
Mylibrary = () => {

}
class Mylibrary extends Component {
    constructor() {
        super(); this.state = { user_id: "", ebook_id: "" }
    }
    storeData = async (key, value) => {
        try {
          await AsyncStorage.setItem(key,value);
        } catch (error) {
          // Error saving data
        }
      };

    componentDidMount(){
        this.retrieveData()
    }
    retrieveData = async (key) => {
        try {
          const value = await AsyncStorage.getItem('user_id');
          if (value !== null) {
            // We have data!!
             this.setState({user_id: value})
          }
        } catch (error) {
          // Error retrieving data
        }
    
        try {
            const value = await AsyncStorage.getItem('ebook_id');
            if (value !== null) {
              // We have data!!
               this.setState({ebook_id: value})
            }
          } catch (error) {
            // Error retrieving data
          }
    
        
      };


    onPressrequestbook2 = () => {
        const url = "http://towunmicoker.com/admin/apis/v1/addEbookViewRequest.php"
        const formData = new FormData();
        formData.append("user_id", this.state.user_id)
        formData.append("ebook_id", this.state.ebook_id)
        alert(JSON.stringify(formData));
        fetch(url,
            {
                method: "POST",
                Body: formData
            }
        )
        .then((response)=>response.json())
        .then((responseJson)=>{
            // alert(JSON.stringify(responseJson));
            if (responseJson && responseJson.status == 'success') {
                
        //         //console.log("responseJson ====",responseJson );
               this.storeData("user_id", responseJson.data.user_id)
               this.storeData("ebook_id", responseJson.data.ebook_id)

            } else if(responseJson.status == "error") {
                alert(responseJson.message);
           } else {
                alert(responseJson.status);
           }
           
        })
        .catch((error) => {
            alert(responseJson.message)
            console.error(error);
        }
        );
        }
    render() {
        return (

            <View style={{ flex: 1, backgroundColor: "white" }}>
                <View style={{
                    width: "100%",
                    flexDirection: "row",
                    height: 50,
                    alignItems: "center",
                    justifyContent: "space-around",

                }}>
                    <TouchableOpacity
                        onPress={() => {
                            Actions.pop()
                        }
                        }

                    >
                        <Icon style={{ paddingRight: 50, color: "purple" }}
                            name='arrowleft'
                            type='AntDesign'
                            fontSize='20'
                        />
                    </TouchableOpacity>

                    <Text style={{
                        color: "purple",
                        fontSize: 30,

                    }}>My Library</Text>

                    <View style={{ width: 50, height: 30 }}>

                    </View>
                </View>



                <View style={{
                    width: "100%",
                    height: 40,
                    alignItems: "flex-start",
                    justifyContent:"center",
                    backgroundColor: "purple",
                    paddingLeft:10

                }}>

                    <Text style={{
                        color: "white",
                        fontSize: 20,
                    }}>Your Books</Text>
                   
                </View>


                <ScrollView >
                    <View style={{ flex: 1 }}>
                        <View style={{ width: "100%", height: "100%", backgroundColor: "white", paddingTop: 10, flexDirection: "row" }}>

                            <View style={{ width: "50%", height: "100%", justifyContent: "center", alignItems: "center" }} >
                                <Image style={{ width: "90%" }} source={require('../projectpics/book3.png')}></Image>
                                <TouchableOpacity style={{ width: 80, height: 30, marginTop: 5, alignItems: "center", justifyContent: "center", backgroundColor: "purple", borderRadius: 5 }}>
                                    <Text style={{ color: "white" }} >Read book</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={{ width: "50%", height: "100%", justifyContent: "center", alignItems: "center" }} >
                                <Image style={{ width: "90%" }} source={require('../projectpics/book1.png')}></Image>
                                <TouchableOpacity style={{ width: 80, height: 30, marginTop: 5, alignItems: "center", justifyContent: "center", backgroundColor: "purple", borderRadius: 5 }}>
                                    <Text style={{ color: "white" }}>Read book</Text>
                                </TouchableOpacity>
                            </View>

                        </View>
                    </View>

                    <View style={{ flex: 1 }}>
                        <View style={{ width: "100%", height: "100%", backgroundColor: "white", paddingTop: 10, flexDirection: "row" }}>

                            <View style={{ width: "50%", height: "100%", justifyContent: "center", alignItems: "center" }} >
                                <Image style={{ width: "90%" }} source={require('../projectpics/book3.png')}></Image>
                                <TouchableOpacity style={{ width: 80, height: 30, marginTop: 5, alignItems: "center", justifyContent: "center", backgroundColor: "purple", borderRadius: 5 }}>
                                    <Text style={{ color: "white" }} >Read book</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={{ width: "50%", height: "100%", justifyContent: "center", alignItems: "center" }} >
                                <Image style={{ width: "90%" }} source={require('../projectpics/book2.png')}></Image>
                                <TouchableOpacity style={{ width: 80, height: 30, marginTop: 5, alignItems: "center", justifyContent: "center", backgroundColor: "purple", borderRadius: 5 }}>
                                    <Text style={{ color: "white" }}>Read book</Text>
                                </TouchableOpacity>
                            </View>

                        </View>
                    </View>

                    <View style={{ flex: 1 }}>
                        <View style={{ width: "100%", height: "100%", backgroundColor: "white", paddingTop: 10, flexDirection: "row" }}>

                            <View style={{ width: "50%", height: "100%", justifyContent: "center", alignItems: "center" }} >
                                <Image style={{ width: "90%" }} source={require('../projectpics/book1.png')}></Image>
                                <TouchableOpacity style={{ width: 80, height: 30, marginTop: 5, alignItems: "center", justifyContent: "center", backgroundColor: "purple", borderRadius: 5 }}>
                                    <Text style={{ color: "white" }} >Read book</Text>
                                </TouchableOpacity>
                            </View>

                            <View style={{ width: "50%", height: "100%", justifyContent: "center", alignItems: "center" }} >
                                <Image style={{ width: "90%" }} source={require('../projectpics/book3.png')}></Image>
                                <TouchableOpacity style={{ width: 80, height: 30, marginTop: 5, alignItems: "center", justifyContent: "center", backgroundColor: "purple", borderRadius: 5 }}>
                                    <Text style={{ color: "white" }}>Read book</Text>
                                </TouchableOpacity>
                            </View>

                        </View>
                    </View>



                  
                        



                </ScrollView>

            </View>
        )
    }
}
export default Mylibrary;