//SignUp.js

import React from 'react'
import { StyleSheet, Text, TextInput, View, Button, ScrollView, Dimensions, Image, TouchableOpacity, onPress, AppRegistry, KeyboardAvoidingView } from 'react-native'
//import firebase from 'react-native-firebase'
import firebase from 'firebase'
import { Content, Icon } from 'native-base';
import Styles from "./Styles"
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import CountryPicker, { getAllCountries } from 'react-native-country-picker-modal';
import Firebase from './firebase';


const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;



export default class SignUp extends React.Component {
  state = {
    email: '',
    password: '',
    errorMessage: null
  }

  handleSignUp = () => {
    const { email, password } = this.state
    firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then(user => this.props.navigation.navigate("SignUpSecond"))
      .catch((error) =>
        {
              this.setState({ loading: false });
                alert('Login Failed. Please try again'+error);
    });
  }

  render() {
    return (
        <View style={{ backgroundColor: "white", height: screenheight }}>

<KeyboardAvoidingView
      style={Styles.kbview2}
      behavior="padding"
      >

                <View style={Styles.view2signupscreen} >
                    <Image source={require('../projectpics/logo.jpg')}
                    style={Styles.imageviewsignupscreen} />
        </View>

        <View style={Styles.view3signupscreen}>
              
        {this.state.errorMessage &&
          <Text style={{ color: 'red' }}>
            {this.state.errorMessage}
          </Text>}

        <TextInput 
          placeholder="Email"
          placeholderTextColor="white"
          autoCapitalize="none"
          style={Styles.nameview}
          onChangeText={email => this.setState({ email })}
          value={this.state.email}
        />
        <TextInput style={Styles.nameview}
          secureTextEntry
          placeholder="Password"
          placeholderTextColor="white"
          autoCapitalize="none"
          style={Styles.nameview}
          onChangeText={password => this.setState({ password })}
          value={this.state.password}
        />

                
              <TouchableOpacity style={Styles.buttonview}
                    onPress={this.handleSignUp} >
                    <Text style={Styles.fonttext21}>Sign Up</Text>
               </TouchableOpacity>
               
               <View style={{ height: 12 }} />


               <TouchableOpacity
                    onPress={() => this.props.navigation.navigate('accountsignup')} >
                    <Text style={Styles.fonttext}>Already have an Account? Log In</Text>
                </TouchableOpacity>

    
      </View>

      </KeyboardAvoidingView>
      
      
            </View>
    )
  }
}