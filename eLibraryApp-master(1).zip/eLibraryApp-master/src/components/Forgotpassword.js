import React, { Component } from 'react';
import { Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import { Button } from 'react-native';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import Styles from "./Styles"
import { Content, Input } from 'native-base';
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;

class forgotPassword extends Component {

    constructor() {
        super(); this.state = { Email: "" }
    
}
    Login = () => {


    }

    onPressforgot = () => {
        const url = "http://towunmicoker.com/admin/apis/v1/forgotPassword.php"

        const formData = new FormData();
        formData.append("email", this.state.Email)
        

        fetch(url, {
            method: 'POST',
            headers: {
               'Content-Type': 'multipart/form-data',
           },
            body: formData
        })
            .then((response) => response.json())
            .then((responseJson) => {
             //   alert(responseJson);
                if (responseJson) {
                    if(responseJson['status'] == "success") {
                        alert(responseJson.message);
                         this.props.navigation.navigate("Login")
                    } else if(responseJson['status'] == "error") {
                         alert(responseJson['message']);
                    } else {
                         alert(responseJson['status']);
                    }
                 } else {
                     alert('error');
                  }
 
             })
            .catch((error) => {
                alert(" failed")
                console.error(error);
            });

    }




    render() {

        return (
            <Content>
                <View style={{ backgroundColor: "white", height: screenheight }}>
                    <View style={Styles.view2} >
                        <Image source={require('../projectpics/logo.jpg')}
                            style={Styles.imageviewsignupscreen} />
                    </View>

                    <View style={{
        width:"100%",
        height:"50%",
        justifyContent: "space-around",
        backgroundColor: "purple",
        paddingTop: 30,
        paddingBottom: 30,
        

    }}>

                        <TextInput style={Styles.nameview}
                            placeholder= "Email"
                            placeholderTextColor="white"
                            onChangeText={(text) => { this.setState({ Email: text }) }}
                            value={this.state.Email} 
                           
                            />
                       
                        <TouchableOpacity style={Styles.buttonview}
                            
                            onPress={() => {
                                this.onPressforgot()
                            }}
                        >
                            <Text style={Styles.fonttext21}>Submit</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            onPress={() => {
                                Actions.pop()

                            }
                            }
                        >
                            <Text style={Styles.fonttext}>Do you have Account? Log In</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </Content>
        )
    }
}
export default forgotPassword;