import SignUpSecond from './SignUpSecond'
import firebase from 'firebase'

export const saveUserDetails = ({Firstname, Lastname, cca2, callingCode }) => {
    const { currentUser } = firebase.auth();
    firebase.database().ref(`users/${currentUser.uid}/userDetails`)
    .push({ Firstname, Lastname, cca2, callingCode });
};