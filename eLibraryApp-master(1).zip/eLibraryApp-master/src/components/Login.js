// Login.js
import React from 'react'
import { StyleSheet, Text, Switch, TextInput, View, Button, Dimensions, Image, TouchableOpacity, onPress, AppRegistry, KeyboardAvoidingView } from 'react-native'
import firebase from 'react-native-firebase'
import Styles from "./Styles"


const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;

export default class Login extends React.Component {
  constructor(props) {
    super(props);
    this.toggleSwitch = this.toggleSwitch.bind(this);
    this.state = {
      showPassword: true,
    }
  }
  
  toggleSwitch() {
    this.setState({ showPassword: !this.state.showPassword });
  }

  state = { email: '', password: '', errorMessage: null }
  handleLogin = () => {
    
    // TODO: Firebase stuff...
      const { email, password } = this.state
    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then(() => this.props.navigation.navigate('accountlogin'))
      .catch((error) => { this.setState({ loading: false });
        alert('Login Failed. Please try again'+error);
    });
  }
  render() {
    return (
        


        <View style={{ backgroundColor: "white", height: screenheight }}>

<KeyboardAvoidingView
      style={Styles.view2}
      behavior="padding"
      >

        <View style={Styles.view2} >
            <Image source={require('../projectpics/logo.jpg')}
            style={Styles.imageviewsignupscreen} />
        </View>
    
        <View style={Styles.view3signupscreen}>
      
    


        {this.state.errorMessage &&
          <Text style={{ color: 'red' }}>
            {this.state.errorMessage}
          </Text>}
        <TextInput
          style={Styles.nameview}
          autoCapitalize="none"
          placeholder="Email"
          placeholderTextColor="white"
          onChangeText={email => this.setState({ email })}
          value={this.state.email}
        />
        <TextInput
          secureTextEntry={this.state.showPassword}
          style={Styles.nameview}
          autoCapitalize="none"
          placeholder="Password, Toggle the switch below to show/hide"
          placeholderTextColor="white"
          onChangeText={password => this.setState({ password })}
          value={this.state.password}
        />
          <Switch
          onValueChange={this.toggleSwitch}
          value={!this.state.showPassword}
        /> 
            
              
              <TouchableOpacity style={Styles.buttonview}
                    onPress={this.handleLogin} >
                        <Text style={Styles.fonttext21}>Log In</Text>
              </TouchableOpacity>

              <TouchableOpacity
                     onPress={() => this.props.navigation.navigate('SignUp')}>
                        <Text style={Styles.fonttext}>Don't have Account? Sign Up
                        </Text>
              </TouchableOpacity>


              </View>
              </KeyboardAvoidingView>

        </View>
    )
  }
}


