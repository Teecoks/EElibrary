import firebase from 'firebase';

const firebaseConfig = {
    apiKey: "AIzaSyAQMk2uR1rYKg8Lr4DUxlimmTycY4r_FpM",
    authDomain: "fir-library-5d543.firebaseapp.com",
    databaseURL: "https://fir-library-5d543.firebaseio.com",
    projectId: "fir-library-5d543",
    storageBucket: "fir-library-5d543.appspot.com",
    messagingSenderId: "1045957216664",
    appId: "1:1045957216664:web:f49e51425dcd8089"
  };
  // Initialize Firebase
  const Firebase = firebase.initializeApp(firebaseConfig);


export default Firebase;