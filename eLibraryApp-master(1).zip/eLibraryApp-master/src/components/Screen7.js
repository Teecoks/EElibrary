import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import Styles from "./Styles";
import { Icon, Left, Body, Item } from 'native-base';
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;
Screen7 = () => {
}
class Screen7 extends Component {

    constructor() {
        super(); 
        this.state = {  ebook_id: "", book:"" }
    }
   

    componentDidMount(){
        this.retrieveData()
            //  this.onPressrequestbook()
            // alert(this.props.data)
             
    }
    retrieveData = async (key) => {
        try {
          const value = await AsyncStorage.getItem('id');
          if (value !== null) {
            // We have data!!
             this.setState({user_id: value})
            // alert(value)
          }
        } catch (error) {
          // Error retrieving data
        }
    
    
        
      };


    onPressrequestbook = () => {
        const url = "http://towunmicoker.com/admin/apis/v1/getEbookById.php"
        const formData = new FormData();
     //   formData.append("user_id", this.state.user_id)
    //  alert(this.props.data)
     formData.append("ebook_id", this.props.data.toString())
    //   alert(JSON.stringify(formData));
        fetch(url,
            {
                method: "POST",
                Body: formData
            })
        .then((response)=>response.json())
        .then((resultJson)=>{
             alert(JSON.stringify(resultJson));
        //     if (responseJson && responseJson.status == 'success') {
        // //         //console.log("responseJson ====",responseJson );
        //        this.storeData("user_id", responseJson.data.user_id);
               this.setState({ book: responseJson.data })
        //       // this.storeData("ebook_id", responseJson.data.ebook_id)

        //     } else if(responseJson.status == "error") {
        //         alert(responseJson.message);
        //    } else {
        //         alert(responseJson.status);
        //    }
           
        })
        // .catch((error) => {
        //     alert(responseJson.message)
        //     console.error(error);
        // }
        // );
        }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: "white" }} >
                <View style={{
                    width: "100%", height: 50, backgroundColor: "white",
                    alignItems: "center", justifyContent: "space-between", flexDirection: "row"
                }} >
                    <TouchableOpacity
                        onPress={() => {
                            Actions.pop()
                        }}
                    >
                        <Icon style={{ color: "purple", marginLeft: 10 }}
                            name='arrowleft'
                            type='AntDesign'

                        />
                    </TouchableOpacity>
                    <Text style={{ color: "purple", fontSize: 20 }}>....{this.state.book.title}</Text>

                    <View style={{ width: 40, height: 30 }}>
                    </View>
                </View>

                <View style={{
                    width: "100%", height: "80%", backgroundColor: "white",
                    alignItems: "center", justifyContent: "space-around"
                }} >

                    <Image source={{uri:this.state.book.imgurl}}
                        style={Styles.imageview} />

                    <Text style={{ fontSize: 20, fontWeight: "bold" }}>......... {this.state.book.discription} </Text>
                </View>
                <View style={{ width: "100%", height: 50, justifyContent: "center", alignItems: "center", backgroundColor: "white" }} >

                    <TouchableOpacity style={{
                        width: "70%", height: 40, borderRadius: 5, justifyContent: "center",
                        alignItems: "center", backgroundColor: "purple"
                    }}
                    onPress={()=>{
                        this.onPressrequestbook()
                    }}
                    >
                        <Text style={{
                            fontSize: 15, alignItems: "center", color: "white",
                            justifyContent: "center",
                        }}>
                        Request Book And Start Reading
                        </Text>
                    </TouchableOpacity>



                </View>
            </View>
        )
    }
}
export default Screen7;