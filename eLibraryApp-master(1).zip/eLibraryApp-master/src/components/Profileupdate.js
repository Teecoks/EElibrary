import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {  Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import { Button } from 'react-native';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import Styles from "./Styles"
import { Content, Input, Icon } from 'native-base';
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;
Profileupdate = () => {

}
class Profileupdate extends Component {



  constructor() {
    super();
    this.state = { firstName: "", email: "", lastName: "", phone: "", ID: "", Email: "", Password: "" }
  }
  storeData = async (key, value) => {
    try {
      await AsyncStorage.setItem(key, value);
    } catch (error) {
      // Error saving data
    }
  };
  componentDidMount() {
    this.retrieveData()
  }
  retrieveData = async (key) => {
    try {
      const value = await AsyncStorage.getItem('first_name');
      if (value !== null) {
        // We have data!!
        this.setState({ firstName: value })
      }
    } catch (error) {
      // Error retrieving data
    }

    try {
      const value = await AsyncStorage.getItem('last_name');
      if (value !== null) {
        // We have data!!
        this.setState({ lastName: value })
      }
    } catch (error) {
      // Error retrieving data
    }

    try {
      const value = await AsyncStorage.getItem('email');
      if (value !== null) {
        // We have data!!
        this.setState({ email: value })
      }
    } catch (error) {
      // Error retrieving data
    }

    try {
      const value = await AsyncStorage.getItem('phone');
      if (value !== null) {
        // We have data!!
        this.setState({ phone: value })
      }
    } catch (error) {
      // Error retrieving data
    }

    try {
      const value = await AsyncStorage.getItem('id');
      if (value !== null) {
        // alert(JSON.stringify(value));
        // We have data!!
        this.setState({ ID: value })
      }
    } catch (error) {
      // Error retrieving data
    }


  };
  onPressupdateprofile2 = () => {
    const url = "http://towunmicoker.com/admin/apis/v1/updateUserProfile.php"

    const formData = new FormData();
    formData.append("first_name", this.state.firstName);
    formData.append("last_name", this.state.lastName);
    formData.append("phone", this.state.phone);
    formData.append("user_id", this.state.ID);

    
    fetch(url, {
      method: 'POST',
      // headers: {
      //  'Content-Type': 'multipart/form-data',
      //  },
      body: formData
    })
    
      .then((response) => response.json())
      .then((responseJson) => {
        alert(JSON.stringify(responseJson));
        if (responseJson && responseJson.status == 'success') {

          //alert(responseJson.message);
          ////console.log("responseJson ====",responseJson );
             this.storeData("firstName", this.state.firstName);
             this.storeData("lastName", this.state.last_name);
             this.storeData("phone", this.state.phone);
             this.props.navigation.navigate("accountlogin")


          // alert(JSON.stringify(storeData))
          //  this.props.navigation.navigate("accountlogin")
        } else if (responseJson.status == "error") {
          alert(responseJson.message);
        } else {
          alert(responseJson.status);
        }

      })
      .catch((error) => {
        alert(responseJson.message)
        console.error(error);
      });

  }


  render() {

    return (
      <Content>
        <View style={{ backgroundColor: "white", height: screenheight }}>

          <View style={{
            width: "100%", height: 40, backgroundColor: "white",
            alignItems: "center", justifyContent: "space-between", flexDirection: "row"
          }} >
            <TouchableOpacity
              onPress={() => {
                Actions.pop()
              }}
            >
              <Icon style={{ color: "purple", marginLeft: 10 }}
                name='arrowleft'
                type='AntDesign'

              />
            </TouchableOpacity>

          </View>
          <View style={{
            width: "100%",
            height: "32%",
            justifyContent: "flex-start",
            alignItems: "center",
            backgroundColor: "white"
          }} >
            <View style={{ width: "100%", height: 30, backgroundColor: "white", justifyContent: "flex-end" }}>
              <TouchableOpacity>
                <Icon style={{ paddingLeft: 300 }}
                  name="account-edit"
                  type="MaterialCommunityIcons"
                />
              </TouchableOpacity>
            </View>
            <Image source={require('../projectpics/user.png')}
              style={Styles.imageviewsignupscreen} />
          </View>

          <View style={Styles.view3signupscreen}>

            <TextInput style={Styles.nameview}
              placeholder="First name"
              placeholderTextColor="white"
              onChangeText={(text) => { this.setState({ firstName: text }) }}
              value={this.state.firstName}
              onSubmitEditing={() => this.Pass.focus()}
            />
            <TextInput style={Styles.nameview}
              placeholder="Last name"
              placeholderTextColor="white"
              onChangeText={(text) => { this.setState({ lastName: text }) }}
              value={this.state.lastName}
              ref={(Input) => this.Pass = Input}
              onSubmitEditing={() => this.new.focus()}
            />
            <TextInput style={Styles.nameview}
              placeholder="phone number"
              placeholderTextColor="white"
              onChangeText={(text) => { this.setState({ phone: text }) }}
              value={this.state.phone}
              ref={(Input) => this.new = Input}
            />

            <TouchableOpacity style={Styles.buttonview}
              onPress={() => {
                this.onPressupdateprofile2()
                // Actions.Login()

              }
              }
            >
              <Text style={Styles.fonttext21}>Save</Text>
            </TouchableOpacity>

          </View>
        </View>
      </Content>
    )
  }
}
export default Profileupdate;