import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {Text, View, TouchableOpacity, AppRegistry, TextInput, Image, Alert, ScrollView, KeyboardAvoidingView } from 'react-native';
import { Icon, Left, Content } from 'native-base';
import { Actions, Router, Scene, Stack, Drawer } from 'react-native-router-flux';
import { DrawerActions } from 'react-navigation';
import firebase from 'firebase'
import LiveChat from 'react-native-livechat';
import { GiftedChat } from 'react-native-gifted-chat';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import Firebase from './firebase';



// const { currentUser } = firebase.auth();
// let nameRef = firebase.database().ref(`/users/${currentUser.uid}/userDetails`);

Main = () => {

}
class Main extends Component {
    
    state = {
        headerName: ""
    }
    
    constructor() {
        super(); this.state = { title: "", books: [], author :"" ,discription:"",slogan:"", category:"", imgurl:""}

    }


    storeData = async (key, value) => {
        try {
            await AsyncStorage.setItem(key, value);
        } catch (error) {
            // Error saving data
        }
    };
    componentDidMount() {
        this.retrieveData()
        this.onPresshome()


    }
    retrieveData = async (key) => {
        try {
            const value = await AsyncStorage.getItem('title');
            if (value !== null) {
                // We have data!!
                this.setState({ title: value })
            }
        } catch (error) {
            // Error retrieving data
        }
        try {
            const value = await AsyncStorage.getItem('author');
            if (value !== null) {
                // We have data!!
                this.setState({ author: value })
            }
        } catch (error) {
            // Error retrieving data
        }
        try {
            const value = await AsyncStorage.getItem('discription');
            if (value !== null) {
                // We have data!!
                this.setState({ discription: value })
            }
        } catch (error) {
            // Error retrieving data
        }

        try {
            const value = await AsyncStorage.getItem('slogan');
            if (value !== null) {
                // We have data!!
                this.setState({ slogan: value })
            }
        } catch (error) {
            // Error retrieving data
        }

        try {
            const value = await AsyncStorage.getItem('category');
            if (value !== null) {
                // We have data!!
                this.setState({ category: value })
            }
        } catch (error) {
            // Error retrieving data
        }
        try {
            const value = await AsyncStorage.getItem('imgurl');
            if (value !== null) {
                // We have data!!
                this.setState({ imgurl: value })
            }
        } catch (error) {
            // Error retrieving data
        }
        
    };

    onPresshome = () => {
        const url = "http://towunmicoker.com/admin/apis/v1/getEbooks.php";

        //  const formData = new FormData();
        // formData.append("user_id", this.state.user_id)
        // formData.append("ebook_id", this.state.ebook_id)
        fetch(url, {
            method: 'GET',

            // body: formData
        })
            .then((response) => response.json())
            .then((responseJson) => {
                   this.storeData("ebook_id", responseJson.data.id);
                   this.storeData("id", responseJson.data[0].id);
                   alert(this.storeData.ebook_id);
                   alert(JSON.stringify(responseJson.data.length));
                this.setState({ books: responseJson.data })
                   if (responseJson && responseJson.status == 'success') {
                       

                      alert(responseJson.message);
                    } else if(responseJson.status == "error") {
                        alert(responseJson.message);
                   } else {
                        alert(responseJson.status);
                   }

            })
            .catch((error) => {
                alert(responseJson.message)
                console.error(error);
            });

    }

    render() {
        return (

            

            <View style={{ flex: 1 }}>
                <View style={{
                    width: "100%",
                    flexDirection: "row",
                    height: 50,
                    alignItems: "center",
                    justifyContent: "space-between",

                }}>

                


                    <TouchableOpacity
                        onPress={() => {
                            Actions.drawerOpen();
                        }
                        }
                    >
                        <Left>
                            <Icon style={{ marginLeft: 10, marginTop: 10, color: "purple" }}
                                name='menu-fold'
                                type='AntDesign'
                            />
                        </Left>

                    </TouchableOpacity>

                    <Text style={{
                        color: "purple",
                        fontSize: 40,

                    }}> Hi Test </Text>

                    <TouchableOpacity style={{ alignItems: "center", justifyContent: "center" }}
                        onPress={() => {
                            Actions.account()
                        }
                        }
                    >
                        <Icon style={{ marginRight: 10, fontSize: 35, color: "purple" }}
                            name='user-circle'
                            type='FontAwesome'
                        />

                    </TouchableOpacity>


                </View>



                <View style={{ width: "100%", height: "25%", backgroundColor: "purple", flexDirection: "row" }}>
                    <View style={{
                        width: "50%",
                        height: 150,
                        backgroundColor: "purple",
                        alignItems: "center",
                        justifyContent: "center"
                    }}>


                        <Text style={{
                            alignSelf: "center",
                            color: "white",
                            paddingHorizontal: 10,
                            fontSize: 23,
                            paddingBottom: 10
                        }}>Continue Reading</Text>

                        <TouchableOpacity style={{
                            width: "80%",
                            height: 40,
                            backgroundColor: "white",
                            alignItems: "center",
                            justifyContent: "center",
                            marginTop: 10,
                            borderRadius: 5
                        }}
                            onPress={() => {
                                Actions.Library()
                            }
                            }
                        >
                            <Text style={{
                                color: "purple"
                            }}>Go to my Library</Text>

                        </TouchableOpacity>
                    </View>
                    <View style={{ width: "50%", height: 150, justifyContent: "center", alignItems: "center" }} >

                        <Image style={{ width: 100, height: 100, borderRadius: 50 }} source={require('../projectpics/logo.jpg')}></Image>

                    </View>
                </View>
                <Content>
                    <ScrollView  >

                        {this.state.books.map((item) => {
                            return <View style={{ width:"100%", backgroundColor: "white" }}>
                                <View style={{
                                    width: "100%", backgroundColor: "white", flexDirection: "row",
                                     marginTop: 1, alignSelf:"center",borderWidth:0.5,borderColor:"silver"
                                }}>
                                     

                                    <Image style={{ width: 100, height: 150 }} source={{uri:item.imgurl}}></Image>
                                    <View style={{ width: "50%" }}>
                                        <Text style={{ fontSize: 15, paddingHorizontal: 10, color: "purple" }}>{item.title}</Text>
                                        <Text style={{ fontSize: 10, paddingHorizontal: 10, color: "black" }}> {item.author}</Text>
                                        <Text style={{ fontSize: 10, paddingHorizontal: 10, color: "black" }}> {item.slogan}</Text>
                                        <Text style={{ fontSize: 10, paddingHorizontal: 10, color: "black" }}>{item.category}</Text>
                                        <Text style={{ fontSize: 10, paddingHorizontal: 10, color: "black", paddingTop: 10, textAlign: "auto" }}>
                                            {item.discription} </Text>
                                    </View>

                                    <View style={{ width: "20%", alignItems: "center", justifyContent: "space-evenly" }}>

                                        <TouchableOpacity

                                            onPress={() => {
                                                // this.onPresshome()
                                                alert(item.author)
                                            }
                                            }
                                        >
                                            <Icon style={{ color: "purple" }}
                                                name="info"
                                                type="Entypo"  />
                                        </TouchableOpacity>
                                        <TouchableOpacity
                                            onPress={() => {
                                            //    alert("item "+ item.id);
                                                Actions.tag(item.id)
                                                
                                            }
                                            }
                                        >
                                            <Icon style={{ color: "purple" }}
                                                name="book-open-variant"
                                                type="MaterialCommunityIcons" />
                                        </TouchableOpacity>
                                    </View>

                                </View>



                            </View>
                        })}


                    </ScrollView>
                </Content>



                
<LiveChat bubbleColor='purple' license="11071237"/>
      



            </View>

        )
    }
}
export default Main;