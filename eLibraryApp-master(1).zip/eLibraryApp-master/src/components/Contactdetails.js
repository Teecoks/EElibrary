import React, { Component } from 'react';
import { View, Text, AppRegistry, TextInput, TouchableOpacity, Picker } from 'react-native';
import { Right, Icon } from 'native-base';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
Contactdetails = () => {

}
class Contactdetails extends Component {
    constructor() {
        super();
        this.state = { Author: "", authors: [], to: "", title: "", Message: "" }
    }
    componentDidMount() {
        this.onpressdetails()
    }

    onpressdetails = () => {
        const url = "http://towunmicoker.com/admin/apis/v1/getAuthorList.php"

        fetch(
            url,
            { method: "GET" }
        )
            .then((response) => response.json())
            .then((responseJson) => {
                this.setState({ authors: responseJson.data })
                //    alert(JSON.stringify(responseJson));

            })
            .catch((error) => {
                alert(responseJson.message)
                console.error(error);
            });
    }
    onPressemailsend = () => {
        const url = " http://towunmicoker.com/admin/apis/v1/sendEmail.php"
        const formData = new FormData();
        formData.append("to", this.state.to)
        formData.append("title", this.state.title)
        formData.append("Message", this.state.Message)
        alert(JSON.stringify(formData));
        
        fetch(
            url, { method: "POST" }
        )
            .then((response) => response.json())
            .then((responseJson) => {
                // alert(JSON.stringify(responseJson));

            })
            .catch((error) => {
                // alert(responseJson.message)
                console.error(error);
            });
    }

    render() {
        return (
            <View style={{ flex: 1, backgroundColor: "white" }}>
                <View style={{
                    flexDirection: "row", width: "100%", height: 50,
                    backgroundColor: "white", alignItems: "center", justifyContent: "space-between", marginTop: 5
                }}>
                    <TouchableOpacity
                        onPress={() => {
                            Actions.pop()
                        }}
                    >
                        <Icon style={{ color: "purple", marginLeft: 10 }}
                            name='arrowleft'
                            type='AntDesign'

                        />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: "purple" }}>Contact</Text>
                    <View style={{ width: 50, height: 30 }}></View>
                </View>
                <View style={{ width: "100%", height: 30 }}>


                    <Picker

                        selectedValue={this.state.Author}
                        style={{ height: "100%", width: "92%", alignSelf: "center" }}
                        onValueChange={(itemValue, itemIndex) => {
                            // alert(itemValue)
                            this.setState({ Author: itemValue })
                        }


                        }
                    >
                        <Picker.Item label="Select a Recipient" value="java" />
                        {this.state.authors.map((item) => {
                            return <Picker.Item key={item.author} label={item.author} value={item.author} />
                        })}
                    </Picker>
                    <TextInput style={{
                        width: "100%", height: 50, fontSize: 15, marginBottom: 10, borderBottomWidth: .5,
                        marginHorizontal: "15%", alignSelf: "center", color: "black"
                    }}
                        placeholder="To"
                        placeholderTextColor="black"
                        onChangeText={(text) => { this.setState({ to: text }) }}
                        value={this.state.to}
                        onSubmitEditing={() => this.Pass.focus()} />

                    <TextInput style={{
                        width: "100%", height: 50, fontSize: 15, marginBottom: 10, borderBottomWidth: .5,
                        marginHorizontal: "15%", alignSelf: "center", color: "black"
                    }}
                        placeholder="Subject"
                        placeholderTextColor="black"
                        onChangeText={(text) => { this.setState({ title: text }) }}
                        value={this.state.title}
                        ref={(Input) => this.try = Input}
                        onSubmitEditing={() => this.hello.focus()} />

                    <TextInput style={{
                        width: "100%", marginTop: 15, borderWidth: .5, height: 150,
                        marginBottom: 60, paddingLeft: 20, fontSize: 15, marginHorizontal: "15%", alignSelf: "center", color: "black"
                    }}
                        placeholder=" Type your message here"
                        placeholderTextColor="black"
                        onChangeText={(text) => { this.setState({ Message: text }) }}
                        value={this.state.Message}
                        ref={(Input) => this.hello = Input}
                        onSubmitEditing={() => this.try.focus()}
                    />



                    <TouchableOpacity style={{ width: "70%", height: 40, alignSelf: "center", borderRadius: 5, backgroundColor: "purple" }}
                        onPress={() => {
                            this.onPressemailsend()
                        }
                        }
                    >
                        <Text style={{ alignSelf: "center", color: "white", paddingTop: 10, fontSize: 15 }}>  Send message  </Text>
                    </TouchableOpacity>

                </View>
            </View>
        )
    }
}
export default Contactdetails;
