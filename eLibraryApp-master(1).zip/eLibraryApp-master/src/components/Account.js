import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {Text, Dimensions, TouchableOpacity, onPress, StyleSheet, View, Image, AppRegistry, TextInput } from 'react-native';
import { Button } from 'react-native';
import Styles from "./Styles"
import { Icon, Left } from 'native-base';
import { Actions } from 'react-native-router-flux';
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;

export default class Account extends Component {

    constructor() {
        super(); this.state = { firstName: "Prissy", lastName: "Coks",phone:"" }
    }
    Account = () => {

    }

    componentDidMount(){
        this.retrieveData()
    }
    retrieveData = async (key) => {
        try {
          const value = await AsyncStorage.getItem('first_name');
          if (value !== null) {
            // We have data!!
             this.setState({firstName: value})
          }
        } catch (error) {
          // Error retrieving data
        }

        try {
            const value = await AsyncStorage.getItem('last_name');
            if (value !== null) {
              // We have data!!
               this.setState({lastName: value})
            }
          } catch (error) {
            // Error retrieving data
          }

          try {
            const value = await AsyncStorage.getItem('phone');
            if (value !== null) {
              // We have data!!
               this.setState({phone: value})
            }
          } catch (error) {
            // Error retrieving data
          }

      };
    render() {
        return (
            <View style={Styles.view1}>
                <View style={{
                    width: "100%", height: "8%", alignItems: "center",
                    marginTop: 10, backgroundColor: "white", flexDirection: "row", justifyContent: "space-between"
                }}>
                    <TouchableOpacity
                        onPress={() => {
                            Actions.pop()
                        }
                        }

                    >
                        <Icon style={{marginLeft:10, color: "purple" }}
                            name='arrowleft'
                            type='AntDesign'
                            fontSize='20'
                        />
                    </TouchableOpacity>
                    <Text style={{ color: "purple", fontSize: 30 }}>Account</Text>
                   <View style={{width:30,height:30}}>

                   </View>
                </View>
                <TouchableOpacity style={{width:"100%",height:100,backgroundColor:"white",justifyContent:"center",alignItems:"center"}}>
              
                    <Image source={require("../projectpics/account.jpg")}
                        style={Styles.imageview2} />
                
                </TouchableOpacity>
                <View style={Styles.accountdetailsview}>
                    
                        <Text style={{ paddingTop: 10 , color:"red"}} >{this.state.phone} </Text>
                        <TouchableOpacity>
                            <Text style={Styles.textchangenumber}> Change phone number </Text>
                        </TouchableOpacity>
                
                </View>

                <View style={Styles.textdetailsview}>
                    <Text style={{ paddingLeft: 15,fontSize:15 }}>First Name</Text>
                    <TextInput style={Styles.accountnameview}
                    editable={false}
                        onChangeText={(text) => { this.setState({ firstName: text }) }}
                        value={this.state.firstName} 
                        placeholder="name"
                        placeholderTextColor="black"
                        />
                    <Text style={{ paddingLeft: 15 }}>Last Name</Text>
                    <TextInput style={Styles.accountnameview}
                    editable={false}
                        onChangeText={(text) => { this.setState({ lastName: text }) }}
                        value={this.state.lastName} />
                </View>

                <View style={Styles.bookmarkmainview}>
                    <View style={Styles.bookmarkfont}>
                        <Text>Bookmark:1</Text>
                    </View>
                    <View style={Styles.bookmarkfont2}>
                        <TouchableOpacity >
                            <Text style={{ color: "purple" }} >View Bookmarks</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                
                    <TouchableOpacity style={Styles.buttonviewred}

                        onPress={() => {
                            Actions.Login()
                        }
                        }


                    >
                        <Text style={Styles.fonttext}>Log Out</Text>
                    </TouchableOpacity>
                </View>
            
        )
    }
}