import { StyleSheet } from 'react-native'



const Styles = StyleSheet.create({

    view1: {
        flex: 1,
        backgroundColor: "white"
    },

    view2: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
    },

    kbview2: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "white",
    },

    imageview: {
        justifyContent: "center",
        alignItems: "center",
        width: 300,
        height: 300
    },

    imageview2: {
        justifyContent: "center",
        alignItems: "center",
        width: 100,
        height: 100,
        borderRadius: 100
    },

    viewimage: {

        justifyContent: "center",
        alignItems: "center",
        width: "100%",
        height: "50%",
        backgroundColor: "gray"

    },

    textdetailsview: {
        width: "100%",
        height: 200,
        backgroundColor: "white",
        justifyContent: "space-around",
        paddingVertical: 20

    },


    view3: {
        flex: 1,
        justifyContent: "space-around",

    },

    nameview: {
        width: "90%",
        height: 40,
        borderBottomWidth: 0.5,
        borderBottomColor: 'black',
        color:"white",
        alignItems:"center",
        alignSelf:"center"


    },

    accountnameview: {
        width: "90%",
        height: 40,
        borderBottomWidth: 0.5,
        borderBottomColor: 'black',
        color:"grey",
        alignItems:"center",
        alignSelf:"center"


    },

    buttonview: {
        width: "70%",
        height: 40,
        backgroundColor: "white",
        alignSelf: "center",
        justifyContent: "center",
        borderRadius:3
    },

    fonttext: {
        fontSize: 20,
        alignSelf: "center",
        justifyContent: "center",
        color:"white",
    },

    fonttext21: {
        fontSize: 20,
        alignSelf: "center",
        justifyContent: "center",
        color:"purple",
    },

    Viewbackground: {
        width:"100%",
        height:"90%",
        backgroundColor: "white",
        justifyContent: "space-around",
        paddingBottom: 30,
        alignItems:"center"


    },

    Viewbackground2: {
        width:"100%",
        height: 200,
        backgroundColor: "purple",
        justifyContent: "center",
        alignItems: "center",
        borderRadius:5,
        

    },

    headerview: {
        width: "100%",
        height: 50,
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "white"
    },

    iconviewleft: {
        paddingLeft: 10,
        marginTop: 10,
        color:"purple"
    },
    iconview: {
        
        justifyContent: "center",
        alignItems: "center",
        paddingLeft:20

    },
    headertextsize: {
        fontSize: 30,
        paddingLeft: 20,
        fontWeight: "bold",
        color:"purple"
    },

    infotextview: {
        width: "100%",
        height: 30,
        backgroundColor: "white",
        justifyContent:"center",
        alignItems: "center",
        flexDirection: "row",
    },


    middlemainview: {
        width: "100%",
        height: 80,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "white",
        flexDirection: "row",
        
    },

    middlesubview: {
        width: "50%",
        height: 80,
        justifyContent: "space-around",
        alignItems: "center",
    },

    middletext: {
        fontSize: 20,
        fontWeight: "bold"
    },

    middletext2: {
        fontSize: 20,
        fontWeight: "bold",
        color: "purple"
    },

    buttonviewred: {
        width: "80%",
        height: 40,
        backgroundColor: "red",
        alignSelf: "center",
        justifyContent: "center",
        borderRadius:5,
        marginTop:30
    },

    imageviewsignupscreen: {
        justifyContent: "center",
        alignItems: "center",
        width: 150,
        height: 150
    },

    view3signupscreen: {
        width:"100%",
        height:"65%",
        justifyContent: "space-around",
        backgroundColor: "purple",
        paddingTop: 30,
        paddingBottom: 30,
        

    },

    view2signupscreen: {
        width: "100%",
        height: "35%",
        justifyContent: "center",
        alignItems: "center"
    },

    textaccount: {
        paddingLeft: 20,
        paddingTop: 30,
        fontSize: 30,
        color: "black"
    },

    accountdetailsview: {
        width: "100%",
        height: 60,
        backgroundColor: "white",
        justifyContent:"center",
        alignItems:"center"
    },

    textnumber: {
        width: "70%",
        height: 60,
        paddingLeft: 110,
        justifyContent: "center",
        alignItems: "center"
    },

    textchangenumber: {
        color: "purple",
        paddingTop: 10
    },

    editprofileview: {
        width: "30%",
        height: 60,
        alignItems: "center",
        justifyContent: "center"
    },

    editprofilefont: {
        width: "25%",
        height: 30,
        alignItems: "center",
        backgroundColor: "white",
        justifyContent: "center",
        borderRadius:5
    },

    bookmarkmainview: {
        width: "100%",
        height: 30,
        flexDirection: "row",
        backgroundColor: "white"
    },

    bookmarkfont: {
        paddingRight: 40,
        width: "50%",
        height: 30,
        justifyContent: "center",
        alignItems: "center"
    },

    bookmarkfont2: {
        width: "50%",
        height: 30,
        alignItems: "center",
        justifyContent: "center"
    },

    redbuttonview: {
        width: "100%",
        height: 150,
        paddingTop: 40
    },

    manageadminmainview: {
        flex: 1,
        backgroundColor: "silver"
    },


    booktextfont: {
        fontSize: 20,
        paddingLeft: 20,
        paddingTop: 20
    },

    textinbook: {
        marginHorizontal: 20,
        paddingTop: 20
    },

    manageadminmaintext: {
        width: "90%",
        height: "20%",
        backgroundColor: "white",
        alignSelf: "center",
        marginTop: 30,
        marginVertical: 10
    },

    manageadminmaintext2: {
        width: "90%",
        height: "20%",
        backgroundColor: "white",
        alignSelf: "center"
    },

    response: {
        textAlign: "center",
        paddingTop: 0,
        padding: 40
    },

    instructions: {

    }

    

})
export default Styles