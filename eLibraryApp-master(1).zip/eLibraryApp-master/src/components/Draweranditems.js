import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {Platform, StyleSheet, Text, View, Image, ScrollView, FlatList, TouchableOpacity, Dimensions } from 'react-native';
import { Actions, Router, Scene, Stack, Drawer } from 'react-native-router-flux';
import { Button, Icon} from 'native-base';
import Login from './Login';
import SignUp from './SignUp';
import Loginsuccess from './Loginsuccess'
const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;
class Draweranditems extends Component{
    constructor() {
        super(); this.state = { firstName: "", email:"", lastName:"", phone:"", ID:"" }
    }

Draweranditems= ()=>{

}

componentDidMount(){
    this.retrieveData()
}
retrieveData = async (key) => {
    try {
      const value = await AsyncStorage.getItem('first_name');
      if (value !== null) {
        // We have data!!
         this.setState({firstName: value})
      }
    } catch (error) {
      // Error retrieving data
    }

    try {
        const value = await AsyncStorage.getItem('email');
        if (value !== null) {
          // We have data!!
           this.setState({email: value})
        }
      } catch (error) {
        // Error retrieving data
      }
      try {
        const value = await AsyncStorage.getItem('last_name');
        if (value !== null) {
          // We have data!!
           this.setState({lastName: value})
        }
      } catch (error) {
        // Error retrieving data
      }

    
  };

  onPressupdateprofile = () => {
    const url = "http://towunmicoker.com/admin/apis/v1/updateUserProfile.php"

    const formData = new FormData();
    formData.append("first_name", this.state.firstName)
    formData.append("last_name", this.state.lastName)
    formData.append("phone", this.state.phone)
    formData.append("user_id", this.state.ID)

    fetch(url, {
        method: 'POST',
       // headers: {
          //  'Content-Type': 'multipart/form-data',
      //  },
        body: formData
    })
        .then((response) => response.json())
        .then((responseJson) => {
            alert(JSON.stringify(responseJson));
            if (responseJson && responseJson.status == 'success') {
                alert(responseJson.message);
                //console.log("responseJson ====",responseJson );
            //    this.storeData("first_name", responseJson.data.first_name)
            //    this.storeData("last_name", responseJson.data.last_name)
            //    this.storeData("phone", responseJson.data.phone)
            //    this.storeData("email", responseJson.data.email)
            //    this.storeData("user_id", responseJson.data.id)

                this.props.navigation.navigate("accountlogin")
            } else if(responseJson.status == "error") {
                alert(responseJson.message);
           } else {
                alert(responseJson.status);
           }
           
        })
        .catch((error) => {
            alert(responseJson.message)
            console.error(error);
        });

}
render(){
    return (
        <View style={{ width: screenWidth * 0.8, height: screenHeight, backgroundColor: 'white' }}>

            <View style={{ width: screenWidth * 0.8, height: "30%", backgroundColor: "purple", alignItems: "center", justifyContent: "center" }}>
                <Image source={require('../projectpics/user.png')}
                    style={{ width: "45%", height: "55%", alignItems:"center"}}
                />
                <Text style={{ color: "white", marginTop: 10 }}>{this.state.firstName} {this.state.lastName}</Text>
                <Text style={{ color: "white", marginVertical: 10 }}>{this.state.email}</Text>
            </View>

            <View style={{ width: "100%", height: "60%", marginTop: 5, backgroundColor: "white",justifyContent:"space-evenly" }}>

                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",
                    alignItems: "center",
                    flexDirection: "row"
                }}
                    onPress={() => {
                        this.props.navigation.closeDrawer(); 
                    }}
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name="home"
                        type='AntDesign'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 30 }}>Home</Text>
                </TouchableOpacity>

                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",
                    alignItems: "center",
                    flexDirection: "row"
                }}
                    onPress={() => {
                        Actions.profile()
                    }}
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name='profile'
                        type='AntDesign'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 30 }}>Profile</Text>
                </TouchableOpacity>

                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",
                    alignItems: "center",
                    flexDirection: "row"

                }}
                    onPress={() => {
                        Actions.Library()
                    }
                    }
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name='library'
                        type='MaterialCommunityIcons'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 30 }}>Library</Text>
                </TouchableOpacity>

                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",

                    alignItems: "center",
                    flexDirection: "row"
                }}
                    onPress={() => {
                        Actions.Booksavailable()
                    }
                    }
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name='book'
                        type='Entypo'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 30 }}>Books Available</Text>
                </TouchableOpacity>

                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",

                    alignItems: "center",
                    flexDirection: "row"

                }}
                    onPress={() => {
                        Actions.Contact()
                    }
                    }
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name='contact-phone'
                        type='MaterialIcons'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 30 }}>Contact</Text>
                </TouchableOpacity>

                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",

                    alignItems: "center",
                    flexDirection: "row"
                }}
                    onPress={() => {
                        Actions.mail()
                    }
                    }
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name='md-settings'
                        type='Ionicons'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 35 }}>Settings</Text>
                </TouchableOpacity>



                    {/* //Payment Page Drawer Component */}
                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",
                    alignItems: "center",
                    flexDirection: "row"
                }}
                    onPress={() => {

                    }}
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name='profile'
                        type='AntDesign'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 30 }}>Subscribe</Text>
                </TouchableOpacity>

                    <View style={{ padding: 5}}>
                    <Text style={{ marginLeft: 10 }}>Communicate</Text>
                    </View>

                <TouchableOpacity style={{
                    width: "100%",
                    height: "15%",               
                    alignItems: "center",
                    flexDirection: "row"
                }}
                    onPress={() => {
                        Actions.share()
                    }
                    }
                >

                    <Icon style={{
                        paddingLeft: 20,
                        color: "purple"
                    }}
                        name='share'
                        type='Entypo'
                        fontSize='20'
                    />
                    <Text style={{ color: "black", paddingLeft: 35 }}>Share</Text>
                </TouchableOpacity>


    </View>

        </View>
    );
}
}
export default Draweranditems; 
