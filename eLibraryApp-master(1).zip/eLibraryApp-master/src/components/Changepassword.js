import React, { Component } from 'react';
import AsyncStorage from '@react-native-community/async-storage';
import {View, Text, AppRegistry, TextInput, TouchableOpacity } from 'react-native';
import { Right, Icon } from 'native-base';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
Changepassword = () => {

}
class Changepassword extends Component {
    constructor() {
        super(); this.state = { Oldpassword: "",Newpassword: "" ,id:"",ConfirmNewpassword:""}
    
}

componentDidMount(){
    this.retrieveData()
}
retrieveData = async (key) => {
    try {
      const value = await AsyncStorage.getItem('id');
      if (value !== null) {
        // We have data!!
         this.setState({id: value})
      }
    } catch (error) {
      // Error retrieving data
    }
};

    onPresschangepassword = () => {
        const url = "http://towunmicoker.com/admin/apis/v1/changePassword.php";
        
        const formData = new FormData();
        formData.append("old_password", this.state.Oldpassword);
        formData.append("new_password", this.state.Newpassword);
        formData.append("user_id", this.state.id)
        fetch(url, {
            method: 'POST',
           // headers: {
              //  'Content-Type': 'multipart/form-data',
          //  },
            body: formData
        }) 
            .then((response) => response.json())
            .then((responseJson) => {
              //  alert(this.state.Oldpassword);
                //alert(JSON.stringify(formData));
                if (responseJson && responseJson.status == 'success') {
                    this.props.navigation.navigate("Login")
                   alert(responseJson.message);
                } else if(responseJson.status == "error") {
                    alert(responseJson.message);
               } else {
                    alert(responseJson.status);
               }
               
            })
            .catch((error) => {
                alert(responseJson.message)
                console.error(error);
            });

    }


    render() {
        return (
            <View style={{ flex: 1, backgroundColor: "white" }}>
                <View style={{
                    flexDirection: "row", width: "100%", height: 50,
                    backgroundColor: "white", alignItems: "center", justifyContent: "space-between", marginTop: 5
                }}>
                    <TouchableOpacity
                        onPress={() => {
                            Actions.pop()
                        }}
                    >
                        <Icon style={{ color: "purple", marginLeft: 10 }}
                            name='arrowleft'
                            type='AntDesign'

                        />
                    </TouchableOpacity>
                    <Text style={{ fontSize: 25, color: "purple" }}>Change password</Text>
                    
                    <View style={{ width: 50, height: 30 }}></View>
                </View>


                <View style={{ width: "100%", height: 200,justifyContent:"center",marginTop:50 }}>
        
                    <TextInput style={{ width: "100%", height: 50, fontSize: 15, 
                    marginBottom: 10, borderBottomWidth: .5, marginHorizontal: "15%",
                     alignSelf: "center", color: "black" }}
                     placeholder={'Old password'}
                     onChangeText={(text) => { this.setState({ Oldpassword: text }) }}
                     value={this.state.Oldpassword} 
            />
                    <TextInput style={{ width: "100%", height: 50, fontSize: 15,
                     marginBottom: 10, borderBottomWidth: .5, marginHorizontal: "15%",
                      alignSelf: "center", color: "black" }}
                      placeholder={"New password"}
                      onChangeText={(text) => { this.setState({ Newpassword: text }) }}
                      value={this.state.Newpassword}
                        
            />
                    <TextInput style={{ width: "100%", height: 50, fontSize: 15,
                     marginBottom: 10, borderBottomWidth: .5, marginHorizontal: "15%",
                      alignSelf: "center", color: "black" }}
                      placeholder={ 'confirm new password'}
                      onChangeText={(text) => { this.setState({ ConfirmNewpassword: text }) }}
                      value={this.state.ConfirmNewpassword}
                      
             />
                      
            
</View>

                    <TouchableOpacity style={{ width: "70%", height: 40, marginTop: 30,
                     alignSelf: "center", justifyContent: "center", backgroundColor: "purple",borderRadius:5 }}
                     onPress={() => {
                        this.onPresschangepassword()
                          //Actions.Login()

                      }
                      }
                     >
                        <Text style={{ alignSelf: "center", justifyContent: "center", color: "white",fontSize:20 }}>  Save  </Text>
                    </TouchableOpacity>

                </View>
            
        )
    }
}
export default Changepassword;
