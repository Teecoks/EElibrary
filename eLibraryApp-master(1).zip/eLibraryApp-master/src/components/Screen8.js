import React, { Component } from 'react';
import { Text, Dimensions, TouchableOpacity, ScrollView, onPress, StyleSheet, View, Image, AppRegistry } from 'react-native';
import { Actions, Router, Scene, Stack } from 'react-native-router-flux';
import Styles from "./Styles"
const screenWidth = Dimensions.get('window').Width;
const screenheight = Dimensions.get('window').height;
Screen8 = () => {

}
class Screen8 extends Component {
    render() {
        return (
            <View style={{ flex: 1 }} >
                <ScrollView>
                    <View style={{ width: 370, height: 700, alignItems: "center",marginTop:10, justifyContent: "flex-start" }}>

                        <Image source={require("../projectpics/Love.png")}
                            style={{
                                justifyContent: "center",
                                alignItems: "center",
                                width: 200,
                                 height: 200
                            }} />
                        <Text style={{marginHorizontal:30,marginVertical:10}}>“When you are able
                            to shift your inner
                             awareness to how you
                             can serve others, and
                              when you make this the
                               central focus of your life,
                                you will then be in a
                                 position to know true
                                  miracles in your progress
                                   toward prosperity.”
</Text>
                    </View>
                    <View style={{ width: 370, height: 700, alignItems: "center", justifyContent: "flex-start" }}>
                        <Text style={{marginHorizontal:30,marginVertical:10}}>“When you are able
                            to shift your inner
                             awareness to how you
                             can serve others, and
                              when you make this the
                               central focus of your life,
                                you will then be in a
                                 position to know true
                                  miracles in your progress
                                   toward prosperity.”
</Text>

                    </View>
                </ScrollView>

            </View>
        )
    }
}
export default Screen8;