/**
 * @format
 */

import React from 'react';
import { Provider } from 'react-redux'
import { AppRegistry } from 'react-native'

import { name as appName } from './app.json';
import Rootpriscilla from './src/components/Rootpriscilla';
import Login from './src/components/Login';
import Draweranditems from './src/components/Draweranditems';
import Screen6 from './src/components/Screen6';
import Screen7 from './src/components/Screen7';
import Screen8 from './src/components/Screen8';
import Changepassword from './src/components/Changepassword';
import Main from './src/components/Main';
import Mylibrary from './src/components/Mylibrary';
import Account from './src/components/Account';

import SignUp from './src/components/SignUp';
import Forgotpassword from './src/components/Forgotpassword';
import Profileupdate from './src/components/Profileupdate';

class APP extends React.Component {
    
    render() {
        return (
            <Provider store={store}>
                <Root />
            </Provider>

        )
    }
}

AppRegistry.registerComponent(appName, () =>Rootpriscilla);
